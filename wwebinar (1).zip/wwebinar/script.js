// script.js
document.addEventListener("DOMContentLoaded", function () {
  // Set webinar details dynamically
  document.getElementById("date").textContent = "July 10, 2023";
  document.getElementById("time").textContent = "10:00 AM - 12:00 PM";
  document.getElementById("duration").textContent = "2 hours";
